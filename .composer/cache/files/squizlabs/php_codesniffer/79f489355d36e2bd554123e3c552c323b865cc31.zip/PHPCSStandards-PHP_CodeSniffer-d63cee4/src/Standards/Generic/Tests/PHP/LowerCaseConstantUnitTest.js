if (variable === true) { }
if (variable === TRUE) { }
if (variable === True) { }
variable = True;

if (variable === false) { }
if (variable === FALSE) { }
if (variable === False) { }
variable = false;

if (variable === null) { }
if (variable === NULL) { }
if (variable === Null) { }
variable = NULL;
